import os
os.environ["DEMO_MODE"] = "true"
os.environ["GEMINI_API_KEY"] = ""

from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_root():
    r=client.get("/")
    assert r.status_code==200 and r.json()["service"]=="LegalEase"

def test_health():
    r=client.get("/health")
    assert r.status_code==200 and r.json()["status"]=="ok"

def test_generate_demo():
    r=client.post("/generate",json={
        "document_type":"NDA",
        "parties":"Alice (Disclosing Party), ABC Ltd (Receiving Party)",
        "terms":"Confidentiality applies; No unauthorized disclosure",
        "effective_date":"2026-10-01",
    })
    assert r.status_code==200
    assert r.json()["demo_mode"] is True
    assert "NDA" in r.json()["content"]

def test_validation():
    r=client.post("/generate",json={
        "document_type":"","parties":"Alice","terms":"Confidentiality","effective_date":"2026-10-01"
    })
    assert r.status_code==422
