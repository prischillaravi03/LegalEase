from backend.services.document_formatter import format_docx, format_html_preview, format_pdf, format_txt

TEXT = "TITLE\n\n1. PURPOSE\nThis is a test document.\n\n2. TERMS\n- Confidentiality applies\n- Payment is due within 30 days\n"

def test_txt():
    assert b"TITLE" in format_txt(TEXT)

def test_docx():
    assert format_docx(TEXT,"Test Agreement")[:2] == b"PK"

def test_pdf():
    assert format_pdf(TEXT,"Test Agreement").startswith(b"%PDF")

def test_html():
    assert "<h3>1. PURPOSE</h3>" in format_html_preview(TEXT)
