# LegalEase

Complete implementation of the supplied LegalEase specification.

## VS Code - Windows

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Put your Gemini API key in `.env`.

Backend:
```powershell
uvicorn backend.main:app --reload --port 8000
```

Frontend, in a second terminal:
```powershell
streamlit run frontend/app.py
```

Open http://localhost:8501.

For UI/export testing without Gemini, set `DEMO_MODE=true` in `.env`.

Tests:
```powershell
pytest -q
```

## macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn backend.main:app --reload --port 8000
```

Use another terminal:
```bash
streamlit run frontend/app.py
```

## API

POST `/generate` accepts:
- `document_type`
- `parties`
- `terms`
- `effective_date`

GET `/health` is the health check.

## Legal note

This application produces AI-assisted drafts and is not legal advice. Review important documents with a qualified legal professional.
