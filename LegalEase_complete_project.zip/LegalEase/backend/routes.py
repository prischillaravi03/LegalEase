from fastapi import APIRouter, HTTPException
from backend.ai_core.gemini_generator import GeminiDocumentGenerator
from backend.config import get_settings
from backend.schemas import DocumentRequest, DocumentResponse

router = APIRouter()
settings = get_settings()
generator = GeminiDocumentGenerator(settings)

@router.get("/health")
def health():
    return {"status":"ok","service":"LegalEase API","demo_mode":settings.demo_mode,"model":settings.gemini_model}

@router.post("/generate", response_model=DocumentResponse)
def generate_document(request: DocumentRequest):
    try:
        content = generator.generate_document(
            request.document_type, request.parties, request.terms, request.effective_date
        )
        return DocumentResponse(
            document_type=request.document_type,
            content=content,
            model=settings.gemini_model,
            demo_mode=settings.demo_mode,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Document generation failed: {exc}")
