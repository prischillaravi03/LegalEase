import html
import re
from io import BytesIO
from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF

BASE_DIR = Path(__file__).resolve().parents[2]
LOGO_PATH = BASE_DIR / "assets" / "logo.png"

def sanitize_text(text):
    replacements = {
        "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
        "\u2013": "-", "\u2014": "-", "\u00a0": " "
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.replace("\x00", "").strip()

def format_txt(text):
    return sanitize_text(text).encode("utf-8")

def _lines(text):
    return [x.strip() for x in sanitize_text(text).splitlines() if x.strip()]

def format_docx(text, doc_type):
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Inches(.75); sec.bottom_margin = Inches(.75)
    sec.left_margin = Inches(.9); sec.right_margin = Inches(.9)
    doc.styles["Normal"].font.name = "Times New Roman"
    doc.styles["Normal"].font.size = Pt(11)

    if LOGO_PATH.exists():
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(str(LOGO_PATH), width=Inches(1.35))

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = title.add_run(doc_type.upper()); r.bold = True; r.font.size = Pt(16)

    for line in _lines(text):
        if re.match(r"^(\d+\.|ARTICLE\s+\d+|SECTION\s+\d+)", line, re.I):
            p = doc.add_paragraph(); r = p.add_run(line); r.bold = True; r.font.size = Pt(12)
        elif line.startswith(("• ", "- ")):
            doc.add_paragraph(line[2:], style="List Bullet")
        else:
            p = doc.add_paragraph(line); p.paragraph_format.space_after = Pt(6)

    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("LegalEase - AI-assisted draft. Review with a qualified legal professional.").italic = True
    out = BytesIO(); doc.save(out); return out.getvalue()

class LegalEasePDF(FPDF):
    def __init__(self, doc_type):
        super().__init__()
        self.doc_type = doc_type
        self.set_auto_page_break(auto=True, margin=18)
    def header(self):
        if LOGO_PATH.exists():
            try: self.image(str(LOGO_PATH), x=95, y=8, w=20)
            except Exception: pass
        self.set_y(30); self.set_font("Helvetica","B",12)
        self.cell(0,8,self.doc_type.upper(),align="C"); self.ln(10)
    def footer(self):
        self.set_y(-13); self.set_font("Helvetica","I",8)
        self.cell(0,8,"LegalEase - AI-assisted draft; review with a qualified legal professional.",align="C")

def format_pdf(text, doc_type):
    pdf = LegalEasePDF(doc_type); pdf.add_page()
    for line in _lines(text):
        heading = bool(re.match(r"^(\d+\.|ARTICLE\s+\d+|SECTION\s+\d+)", line, re.I))
        pdf.set_font("Helvetica","B" if heading else "",11 if heading else 10)
        pdf.multi_cell(0,5,("• " + line[2:]) if line.startswith(("• ","- ")) else line)
        pdf.ln(1)
    return bytes(pdf.output())

def format_html_preview(text):
    escaped = html.escape(sanitize_text(text))
    result = []
    for p in escaped.split("\n"):
        if not p.strip(): continue
        if re.match(r"^(\d+\.|ARTICLE\s+\d+|SECTION\s+\d+)", p, re.I):
            result.append(f"<h3>{p}</h3>")
        else:
            result.append(f"<p>{p}</p>")
    return "".join(result)
