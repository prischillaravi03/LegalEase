import os
from datetime import date
import requests
import streamlit as st
from dotenv import load_dotenv
from backend.services.document_formatter import format_docx, format_html_preview, format_pdf, format_txt

load_dotenv()
BACKEND_URL = os.getenv("BACKEND_URL","http://127.0.0.1:8000").rstrip("/")

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")
st.markdown("""<style>
.main-title{text-align:center;font-size:2.6rem;font-weight:800;margin-bottom:0}
.subtitle{text-align:center;color:#8b95a7;margin-top:.25rem}
.preview{background:#111827;color:#e5e7eb;border-radius:16px;padding:24px;max-height:600px;overflow-y:auto;border:1px solid #374151}
.preview h3{color:#fff;margin-top:18px}
</style>""", unsafe_allow_html=True)

logo = os.path.join(os.path.dirname(__file__),"..","assets","logo.png")
c = st.columns([1,2,1])[1]
with c:
    if os.path.exists(logo): st.image(logo,width=110)

st.markdown('<div class="main-title">LegalEase</div>',unsafe_allow_html=True)
st.markdown('<div class="subtitle">AI-powered legal document drafting assistant</div>',unsafe_allow_html=True)
st.warning("LegalEase creates AI-assisted drafts, not legal advice. Review important documents with a qualified legal professional.")

if "document" not in st.session_state: st.session_state.document = ""
if "document_type" not in st.session_state: st.session_state.document_type = "Non-Disclosure Agreement"

with st.form("generator_form"):
    left,right = st.columns(2)
    with left:
        document_type = st.text_input("Document Type",value=st.session_state.document_type,placeholder="Employment Contract / NDA / Lease Agreement")
        parties = st.text_area("Parties Involved",height=140,placeholder="Jane Doe (Employee), ABC Pvt Ltd (Employer)")
    with right:
        effective_date = st.text_input("Effective Date",value=date.today().isoformat())
        terms = st.text_area("Terms & Conditions",height=140,placeholder="Salary: INR 50000 per month; Confidentiality applies; Notice period: 30 days",help="Separate multiple terms with semicolons.")
    submitted = st.form_submit_button("Generate Document",type="primary",use_container_width=True)

if submitted:
    if not all([document_type.strip(),parties.strip(),effective_date.strip(),terms.strip()]):
        st.error("Please fill in all four fields.")
    else:
        try:
            with st.spinner("Generating your draft..."):
                response = requests.post(f"{BACKEND_URL}/generate",json={
                    "document_type":document_type.strip(),"parties":parties.strip(),
                    "terms":terms.strip(),"effective_date":effective_date.strip()
                },timeout=120)
            if response.ok:
                data = response.json()
                st.session_state.document_type = data["document_type"]
                st.session_state.document = data["content"]
                if data.get("demo_mode"): st.info("Demo mode is enabled. This is a sample, not Gemini output.")
                else: st.success(f"Generated with {data.get('model','Gemini')}.")
            else:
                try: detail = response.json().get("detail",response.text)
                except Exception: detail = response.text
                st.error(f"Backend error: {detail}")
        except requests.RequestException as exc:
            st.error("Could not connect to FastAPI. Start: uvicorn backend.main:app --reload --port 8000")
            st.caption(str(exc))

if st.session_state.document:
    st.divider(); st.subheader("Document Preview")
    st.markdown(f'<div class="preview">{format_html_preview(st.session_state.document)}</div>',unsafe_allow_html=True)
    st.subheader("Edit Document")
    st.session_state.document = st.text_area("Edit the generated text before exporting",value=st.session_state.document,height=500,label_visibility="collapsed")

    st.subheader("Download")
    d1,d2,d3 = st.columns(3)
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in st.session_state.document_type.lower()).strip("_") or "legal_document"
    with d1:
        st.download_button("Download TXT",format_txt(st.session_state.document),f"{safe}.txt","text/plain",use_container_width=True)
    with d2:
        st.download_button("Download DOCX",format_docx(st.session_state.document,st.session_state.document_type),f"{safe}.docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document",use_container_width=True)
    with d3:
        st.download_button("Download PDF",format_pdf(st.session_state.document,st.session_state.document_type),f"{safe}.pdf","application/pdf",use_container_width=True)

st.divider()
st.caption("LegalEase • AI-assisted drafting • Keep your Gemini API key private • Not a substitute for professional legal advice")
